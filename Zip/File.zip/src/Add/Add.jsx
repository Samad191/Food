import React, { Component } from 'react'
import Nav from '../Nav'
export default class Add extends Component {
    render() {
        return (
            <div>
                <Nav />
                Add
            </div>
        )
    }
}
